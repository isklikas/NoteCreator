//
//  LineCreator.h
//  CallShare
//
//  Created by Yannis on 12/9/13.
//
//

#import <UIKit/UIKit.h>

@interface LineCreator : UIView

@end
